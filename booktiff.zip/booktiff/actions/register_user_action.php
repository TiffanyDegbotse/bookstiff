<?php
include '../settings/connection.php';

if (isset($_POST['register'])) {
    //Retrieve form data     
    $firstName = $_POST["firstName"]; 
    $lastName = $_POST["lastName"];                                              
    $email = $_POST["email"]; 
    $contact = $_POST["contact"];
    $password = $_POST["password"]; 
    $role = $_POST["role"]; // Fetch selected role      

    $hashedPassword = password_hash($password, PASSWORD_DEFAULT);

    // Check if email is already in use
    $sql = "SELECT email FROM people WHERE email = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $stmt->store_result();

    if ($stmt->num_rows > 0) {
        $stmt->close();
        echo "<script>
        alert('Email already exists. Please use another one or login in the next page');
        window.location.href='../index.php?error'
        </script>";
    }

    $stmt->close();

    // Prepare INSERT statement with parameterized query
    $sql = "INSERT INTO people (firstname, lastname, email, contact, password) VALUES (?, ?, ?, ?, ?)";
    $stmt = $conn->prepare($sql);

    // Bind parameters
    $stmt->bind_param("sssss", $firstName, $lastName, $email, $contact, $hashedPassword);

    // Execute the statement
    if ($stmt->execute()) {
        echo "Successful Registration";
        header('Location:../index.php?msg=success');
        exit();
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }

    // Close the statement
    $stmt->close();
} else {
    // If form is not submitted, redirect to register view page or take appropriate action
    header('Location:../admin/register.php?msg=error');
    exit();
}

// Close the connection
$conn->close();

